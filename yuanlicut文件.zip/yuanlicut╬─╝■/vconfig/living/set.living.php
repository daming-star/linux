<?php
$vLivingRecSave = '/vdata/relive';
$vLivingRecSavePic = '/vdata/relivepic';
$vLivingHlsPath = '/vdata/hls';
$vLivingTmpPath = '/vtmp/living';

#$vLivingHlsPathNew = '/vdata/tots';

$delbefore = 4;
