<?php
$vLivingRecList[6703] = array(1,'/vdata/hls/6703');
$vLivingRecList[6704] = array(1,'/vdata/hls/6704');
$vLivingRecList[6705] = array(1,'/vdata/hls/6705');
$vLivingRecList[6730] = array(1,'/vdata/hls/6730');
$vLivingRecList[6758] = array(1,'/vdata/hls/6758');
$vLivingRecList[6759] = array(1,'/vdata/hls/6759');
$vLivingRecList[6760] = array(1,'/vdata/hls/6760');
$vLivingRecList[6761] = array(1,'/vdata/hls/6761');
$vLivingRecList[6762] = array(1,'/vdata/hls/6762');
$vLivingRecList[6776] = array(1,'/vdata/hls/6776');
$vLivingRecList[6922] = array(1,'/vdata/hls/6922');
##
$vLivingRecList[6707] = array(1,'/vdata/hls/6707');
$vLivingRecList[6708] = array(1,'/vdata/hls/6708');
$vLivingRecList[6712] = array(1,'/vdata/hls/6712');
$vLivingRecList[6714] = array(1,'/vdata/hls/6714');
$vLivingRecList[6718] = array(1,'/vdata/hls/6718');
$vLivingRecList[6773] = array(1,'/vdata/hls/6773');
$vLivingRecList[6721] = array(1,'/vdata/hls/6721');
$vLivingRecList[6728] = array(1,'/vdata/hls/6728');

$vLivingRecList[6748] = array(1,'/vdata/hls/6748');
$vLivingRecList[7900] = array(1,'/vdata/hls/7900');
$vLivingRecList[6744] = array(1,'/vdata/hls/6744');
$vLivingRecList[6738] = array(1,'/vdata/hls/6738');
$vLivingRecList[6742] = array(1,'/vdata/hls/6742');
$vLivingRecList[6746] = array(1,'/vdata/hls/6742');
$vLivingRecList[6737] = array(1,'/vdata/hls/6737');
$vLivingRecList[6774] = array(1,'/vdata/hls/6774');
$vLivingRecList[6740] = array(1,'/vdata/hls/6740');