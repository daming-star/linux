<?php
/*
+-------------------------------------------------------------------------+
|   基本函数，每个程序默认引用项
+-------------------------------------------------------------------------+
|  主要针对：  所有独立执行文件
+-------------------------------------------------------------------------+
| 设计和编码人员包括：
|   hjy
+-------------------------------------------------------------------------+
| 维护记录：
|   hjy 2014-06-16 创建
|   zxx 2014-10-24 增加调试参数 $vDebug 的判断，该参数可以在base/set.local.php进行配置
					如果在配置文件中设置了为1，则显示所有的调试信息,
|					如果设置为了0， 则隐藏所有的错误信息。
+-------------------------------------------------------------------------+
|           ———— Copyright (C) 2010-2016 The iTalk TV R&D Group
+-------------------------------------------------------------------------+
*/

date_default_timezone_set('Asia/Shanghai');
/**
 * 运行模式
 * @author hjy 2014-06-16 创建
 * @param string $debug
 */
function vLoadRunModel($debug=FALSE){

}

/**
 * 引入公共函数
 * @author hjy 2014-06-18 创建
 * @param string|array $func
 * @param string $model default:base
 */
function vLoadFunction($func,$model="base"){
	if(is_string($func)){
		require_once(sprintf("/vframework/%s/function.%s.php",$model,$func));
	}elseif(is_array($func)){
		foreach ($func as $fc){
			require_once(sprintf("/vframework/%s/function.%s.php",$model,$fc));
		}
	}else{
		return false;
	}
}

/**
 * 引入公共类
 * @author hjy 2014-06-18 创建
 * @param string $class
 * @param string $model default:base
 */
function vLoadClass($class,$model="base"){
	require_once(sprintf("/vframework/%s/class.%s.php",$model,$class));
}

//加载本机信息
require_once "/vconfig/base/set.local.php";
require_once "/vconfig/base/config.local.php";
//增加调试参数的判断
if(isset($vDebug)){
	if($vDebug == 1){
		error_reporting(E_ALL ^ E_NOTICE);
	}else{
		error_reporting(0);
	}
}else{
	error_reporting(0);
}

?>