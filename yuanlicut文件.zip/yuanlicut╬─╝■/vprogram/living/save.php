#!/usr/bin/php
<?php
/*
+---------------------------------------------------------------------------+
| 保存直播文件
+---------------------------------------------------------------------------+
| 主要针对：从transfer的接收端扫描获取文件，转存7日存储
| 运行方式：计划任务
| 主要职能：
|   1、扫描目录检查更新文件
|   2、移动文件
+---------------------------------------------------------------------------+
| 设计和编码人员包括：
|  hujy
+---------------------------------------------------------------------------+
| 维护记录：
|  2016-01-07 hujy 创建 
+---------------------------------------------------------------------------+
|          	     ———— Copyright (C) 2010-2016 The China TV R&D Group
+---------------------------------------------------------------------------+
*/

/* =--==---==----  配置及类和函数的引用  ----==---==--= */
require_once "/vframework/common.php";
require_once "/vconfig/living/set.living.php";
vLoadFunction(array("files","string","curl","date"));

//获取时间段
//$hourb = 18;//18
//$hours = 0;//0

#1# 获取参数
$channel = $argv[1];
if(empty($channel)){
    exit("channel empty");
}
$frompath = $vLivingHlsPath."/".$channel;
if(!is_dir($frompath)){
    exit("path error");
}

#2# 监看目标目录
//无限循环
do{
    //获取切片数组
    $tsarr = vFilesScanPath($frompath);
    if(empty($tsarr)){
        sleep(200);
        continue;
    }
    //print_r($tsarr);exit;

    //分析切片
    foreach ($tsarr as $ts){
    	
    	//echo $ts;
    	$tspath = sprintf("%s/%s",$frompath,$ts);
    	
    	//时间段
    	/*$hournow = substr($ts,9,2);
    	if($hournow<$hourb&&$hournow>$hours){
    		@unlink($tspath);
    		continue;
    	}*/
    	
    	//切片
        if(substr($ts,-3)==".ts"){
        	$newfile = getNewFile($vLivingRecSave,$ts,$channel,"ts");
        	//echo $newfile;exit;
        	//文件存在
        	if(is_file($newfile)){
        		unlink($tspath);
        		continue;
        	}
        	#3# 转存文件
        	if(!rename($tspath,$newfile)){
        		continue;
        	}
        }
        
        //图片
        elseif(substr($ts,-4)==".jpg"){
        	$newfile = getNewFile($vLivingRecSavePic,$ts,$channel,"jpg","big");
        	//echo $newfile;exit;
        	//文件存在
        	if(is_file($newfile)){
        		unlink($tspath);
        		continue;
        	}
        	#3# 转存文件
        	if(!rename($tspath,$newfile)){
        		continue;
        	};
        	
        	//小图
        	$newfilepic = str_replace($channel."big",$channel,$newfile);
        	//echo $newfilepic;exit;
        	$newfilepicdir = dirname($newfilepic);
        	//echo $newfilepicdir;exit;
        	if(!is_dir($newfilepicdir)){
        		vFilesMkdir($newfilepicdir);
        	}
        	mkThumbnail($newfile, 120, 90, $newfilepic);
        }
        
        //exit;
    }

    //exit;
    sleep(60);	//正常任务等待
}while (1);


/* =--==---==----  仅在本文件使用的方法  ----==---==--= */
/**
 * 
 * @param unknown $ts
 * @param unknown $channel
 * @return string
 */
function getNewFile($dir,$ts,$channel,$suffix,$ifbig=""){
    
    $y = substr($ts,0,4);
    $m = substr($ts,4,2);
    $d = substr($ts,6,2);
    $date = sprintf("%s-%s-%s",$y,$m,$d);
    
    $h = substr($ts,9,2);
    $i = substr($ts,11,2);
    $s = substr($ts,13,2);
    $his = sprintf("%s:%s:%s",$h,$i,$s);
    
    $order = substr($ts,16,4);
      
    $time = vDateToTime($date)+vDateHisToS($his);
    
    if(empty($ifbig)){
    	$path = sprintf("%s/%s/%d",$dir,$date,$channel);
    }else{
    	$path = sprintf("%s/%s/%d%s",$dir,$date,$channel,$ifbig);
    }
    
    if(!is_dir($path)){
        vFilesMkdir($path);
    }
    $file = sprintf("%s/%s.%s.%s",$path,$time,$order,$suffix);
    return $file;
}
/**
 * 生成缩略图函数（支持图片格式：gif、jpeg、png和bmp）
 * @author ruxing.li
 * @param  string $src      源图片路径
 * @param  int    $width    缩略图宽度（只指定高度时进行等比缩放）
 * @param  int    $width    缩略图高度（只指定宽度时进行等比缩放）
 * @param  string $filename 保存路径（不指定时直接输出到浏览器）
 * @return bool
 */
function mkThumbnail($src, $width = null, $height = null, $filename = null) {
	if (!isset($width) && !isset($height))
		return false;
	if (isset($width) && $width <= 0)
		return false;
	if (isset($height) && $height <= 0)
		return false;

	$size = getimagesize($src);
	if (!$size)
		return false;

	list($src_w, $src_h, $src_type) = $size;
	$src_mime = $size['mime'];
	switch($src_type) {
		case 1 :
			$img_type = 'gif';
			break;
		case 2 :
			$img_type = 'jpeg';
			break;
		case 3 :
			$img_type = 'png';
			break;
		case 15 :
			$img_type = 'wbmp';
			break;
		default :
			return false;
	}

	if (!isset($width))
		$width = $src_w * ($height / $src_h);
	if (!isset($height))
		$height = $src_h * ($width / $src_w);

	$imagecreatefunc = 'imagecreatefrom' . $img_type;
	$src_img = $imagecreatefunc($src);
	$dest_img = imagecreatetruecolor($width, $height);
	imagecopyresampled($dest_img, $src_img, 0, 0, 0, 0, $width, $height, $src_w, $src_h);

	$imagefunc = 'image' . $img_type;
	if ($filename) {
		$imagefunc($dest_img, $filename);
	} else {
		header('Content-Type: ' . $src_mime);
		$imagefunc($dest_img);
	}
	imagedestroy($src_img);
	imagedestroy($dest_img);
	return true;
}
