#!/usr/bin/php
<?php
/*
+---------------------------------------------------------------------------+
| 对指定文件夹不删除，存储到指定位置
+---------------------------------------------------------------------------+
| 主要针对：
| 运行方式：计划任务
| 主要职能：
|   1、
+---------------------------------------------------------------------------+
| 设计和编码人员包括：
|  wk
+---------------------------------------------------------------------------+
| 维护记录：
|  2017-06-12 wk 创建 
+---------------------------------------------------------------------------+
|          	     ———— Copyright (C) 2016-2026 The China TV R&D Group
+---------------------------------------------------------------------------+
*/

/* =--==---==----  配置及类和函数的引用  ----==---==--= */
require_once "/vframework/common.php";
require_once "/vconfig/living/set.living.php";
vLoadFunction(array("files","string","curl","date"));

$delbefore = 1;
$channel   = 7942;
$day       = date("Y-m-d",time()-$delbefore*86400);

$path  = sprintf("%s/%s/%s",$vLivingRecSave,$day,$channel);
$npath = sprintf("%s/%s/%s",$vLivingRecSave,$channel,$day);
//echo $path.">>>".$npath;exit;
if(is_dir($path)){
	vFilesMkdir($npath);
	$comm = sprintf("mv %s %s",$path,$npath);
	//echo $comm;exit;
	@exec($comm);
}
