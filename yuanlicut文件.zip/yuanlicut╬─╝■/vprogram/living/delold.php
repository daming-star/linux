#!/usr/bin/php
<?php
/*
+---------------------------------------------------------------------------+
| 删除旧文件
+---------------------------------------------------------------------------+
| 主要针对：转存7日存储清理
| 运行方式：计划任务
| 主要职能：
|   1、计算日期N天前
|   2、删除文件夹
+---------------------------------------------------------------------------+
| 设计和编码人员包括：
|  wk
+---------------------------------------------------------------------------+
| 维护记录：
|  2017-09-08 wk 创建 
+---------------------------------------------------------------------------+
|          	     ———— Copyright (C) 2016-2026 The China TV R&D Group
+---------------------------------------------------------------------------+
*/

/* =--==---==----  配置及类和函数的引用  ----==---==--= */
require_once "/vframework/common.php";
require_once "/vconfig/living/set.living.php";
vLoadClass("mysqli");

$time = time()-$delbefore*86400;
$day  = date("Y-m-d",$time);

//删除切片
$path = sprintf("%s/%s",$vLivingRecSave,$day);
@exec(sprintf("rm -Rf %s",$path));

//删除图片
$pathpic = str_replace("relive","relivepic",$path);
@exec(sprintf("rm -Rf %s",$pathpic));

//删除数据
$DB = new vMysqli($vLocalMySQL["mission"][0], $vLocalMySQL["mission"][1],
    $vLocalMySQL["mission"][2],$vLocalMySQL["mission"][3]);
$sql = sprintf("delete from filets where filepath<%d;",$time);
//echo $sql;exit;
$DB->query($sql);
